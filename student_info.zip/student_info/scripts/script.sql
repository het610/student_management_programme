CREATE TABLE students_details (
  s_id int NOT NULL AUTO_INCREMENT,
  first_name varchar(40) DEFAULT NULL,
  last_name varchar(40) DEFAULT NULL,
  city varchar(40) DEFAULT NULL,
  mobile_no bigint DEFAULT NULL,
  email varchar(40) DEFAULT NULL,
  PRIMARY KEY (s_id)
  );