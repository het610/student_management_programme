package com.kot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;


public class Main {

    public static void main(String[] args) throws IOException, SQLException {

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String answer = "y";

        while (answer.equalsIgnoreCase("y")) {

            //display menu
            System.out.println("-----------------Menu-------------");
            System.out.println("Enter 1 for Add Student Detail");
            System.out.println("Enter 2 for Edit Student Detail");
            System.out.println("Enter 3 for Delete Student Detail");
            System.out.println("Enter 4 for Get Specific Student Detail");
            System.out.println("Enter 5 for Get All Student Detail");
            System.out.println("----------------------------------");
            System.out.println("Enter Your Choice :");
            String input = br.readLine();
            int c;
            if (input.matches("-?(0|[1-9]\\d*)")) {
                c = Integer.parseInt(input);
            } else
                c = 0;

            switch (c) {
                case 1:
                    //Add Student Details
                    System.out.println("Enter Your First Name:");
                    String first_name = br.readLine();
                    System.out.println("Enter Your Last Name:");
                    String last_name = br.readLine();
                    System.out.println("Enter Your City:");
                    String city = br.readLine();
                    System.out.println("Enter Your Mobile No:");
                    long mobile_no = Long.parseLong(br.readLine());
                    System.out.println("Enter Your Email:");
                    String email = br.readLine();

                    Student student = new Student(first_name, last_name, city, mobile_no, email);
                    int result = Operation.insert_data(student);
                    if (result > 0) {
                        student.setS_id(result);
                        OperationCSV.insert_data(student);
                        System.out.println("Student details added successfully");
                    } else {
                        System.out.println("Not updated");
                    }
                    break;

                case 2:
                    //Edit Student detail
                    System.out.println("Enter your id");
                    int s_id = Integer.parseInt(br.readLine());
                    Operation.view_data(s_id);
                    System.out.println("Enter Your First Name:");
                    first_name = br.readLine();
                    System.out.println("Enter Your Last Name:");
                    last_name = br.readLine();
                    System.out.println("Enter Your City:");
                    city = br.readLine();
                    System.out.println("Enter Your Mobile No:");
                    mobile_no = Long.parseLong(br.readLine());
                    System.out.println("Enter Your Email:");
                    email = br.readLine();
                    Student student1 = new Student(s_id, first_name, last_name, city, mobile_no, email);
                    result = Operation.update_data(student1);
                    if (result > 0) {
                        OperationCSV.modify(s_id,student1.getStudentDetail(),"update");
                        System.out.println("Student details updated successfully");
                    } else {
                        System.out.println("Not updated");
                    }
                    break;

                case 3:
                    // Delete Student Detail
                    System.out.println("Enter Student id for delete operation:");
                    s_id = Integer.parseInt(br.readLine());
                    Operation.view_data(s_id);
                    System.out.println("Do you want to Delete information?");
                    System.out.println("Please Enter Y for Yes or N for NO");

                    String s = br.readLine();
                    switch (s.toUpperCase()) {
                        case "Y":
                            result = Operation.delete(s_id);
                            if (result > 0) {
                                OperationCSV.modify(s_id,null,"delete");
                                System.out.println("Student details deleted successfully");
                            } else {
                                System.out.println("Student details not deleted");
                            }

                            break;
                        case "N":
                            System.out.println("No,I don't want to delete information.");
                            break;
                        default:
                            System.out.println("Invalid input.Please re-enter your choice: ");
                    }
                    break;

                case 4:
                    //Show specific student details
                    System.out.println("Enter Student id");
                    s_id = Integer.parseInt(br.readLine());
                    Operation.view_data(s_id);
                    break;

                case 5:
                    //Show all students detail
                    Operation.view_data();
                    break;

                default:
                    System.out.println("Invalid input.Please re-enter your choice: ");
            }

            System.out.println("Do you want to perform anything else? Y/N");
            answer= br.readLine();
        }

    }
}
