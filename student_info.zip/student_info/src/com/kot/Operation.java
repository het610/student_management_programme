package com.kot;
import java.io.IOException;
import java.sql.*;


public class Operation {

    public static int insert_data(Student student) throws SQLException, IOException {
        Connection_db obj = new Connection_db();
        Connection connection = obj.get_connection();
        int result = 0;
        PreparedStatement ps = null;
        try {
            String query = "insert into students_details(first_name,last_name,city,mobile_no,email) values(?,?,?,?,?);";
            ps = connection.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, student.getFirst_name());
            ps.setString(2, student.getLast_name());
            ps.setString(3, student.getCity());
            ps.setLong(4, student.getMobile_no());
            ps.setString(5, student.getEmail());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            int generatedKey = 0;
            if(rs.next()){
                generatedKey= rs.getInt(1);
            }
            result = generatedKey;
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        if (ps!= null)
            ps.close();

        return result;
    }

    public static int update_data(Student student1) throws SQLException, IOException {
        Connection_db obj = new Connection_db();
        Connection connection = obj.get_connection();
        int result= 0;
        PreparedStatement ps=null;
        try {
            String query="update students_details set first_name=?,last_name=?,city=?,mobile_no=?,email=? where s_id=?;";
            ps=connection.prepareStatement(query);

            ps.setString(1, student1.getFirst_name());
            ps.setString(2, student1.getLast_name());
            ps.setString(3, student1.getCity());
            ps.setLong(4, student1.getMobile_no());
            ps.setString(5, student1.getEmail());
            ps.setInt(6,student1.getS_id());

            result = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        if (ps!= null)
            ps.close();
        return result;
    }


    public static int delete(int student_id) throws SQLException, IOException {
        Connection_db obj = new Connection_db();
        Connection connection = obj.get_connection();
        int result = 0;
        PreparedStatement ps = null;
        try {
            String query = "delete from students_details where s_id=?;";
            ps = connection.prepareStatement(query);
            ps.setInt(1, student_id);

            result = ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        if (ps!= null)
            ps.close();
        return result;
    }

    public static void view_data(int s_id) throws SQLException, IOException {
        Connection_db obj = new Connection_db();
        Connection connection = obj.get_connection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            String query = "select * from students_details where s_id =?;";
            ps = connection.prepareStatement(query);
            ps.setInt(1, s_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("------------------------------------------------------------------------------------------------");
                System.out.printf("%-5s %-15s %-15s %-10s %-15s %-15s","s_id","first_name", "last_name", "city", "mobile_no", "email");
                System.out.println();
                System.out.println("------------------------------------------------------------------------------------------------");
                System.out.format("%-5s %-15s %-15s %-10s %-15s %-15s",rs.getInt("s_id"),rs.getString("first_name"),
                        rs.getString("last_name"),rs.getString("city"),
                        rs.getLong("mobile_no"),rs.getString("email"));
                System.out.println();
                System.out.println("------------------------------------------------------------------------------------------------");

            }

        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        if (ps!= null)
            ps.close();
        if (rs!= null)
            rs.close();
    }

    public static void view_data() throws SQLException, IOException {
        Connection_db obj = new Connection_db();
        Connection connection = obj.get_connection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            String query = "select * from students_details;";
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            System.out.println("------------------------------------------------------------------------------------------------");
            System.out.printf("%-5s %-15s %-15s %-10s %-15s %-15s","s_id","first_name", "last_name", "city", "mobile_no", "email");
            System.out.println();
            System.out.println("------------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.format("%-5s %-15s %-15s %-10s %-15s %-15s",rs.getInt("s_id"),rs.getString("first_name"),
                        rs.getString("last_name"),rs.getString("city"),
                        rs.getLong("mobile_no"),rs.getString("email"));
                System.out.println();
            }
            System.out.println("------------------------------------------------------------------------------------------------");

        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        if (ps!= null)
            ps.close();
        if (rs!= null)
            rs.close();
    }

}