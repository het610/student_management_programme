package com.kot;

public class Student {

    private int s_id;
    private String first_name;
    private String last_name;
    private String city;
    private long mobile_no;
    private String email;

    public Student(int s_id){
        super();
        this.s_id = s_id;
    }

    public Student(String first_name, String last_name, String city, long mobile_no, String email) {
        super();
        this.first_name = first_name;
        this.last_name = last_name;
        this.city = city;
        this.mobile_no = mobile_no;
        this.email = email;
    }


    public Student(int s_id, String first_name, String last_name, String city, long mobile_no, String email) {
        super();
        this.s_id = s_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.city = city;
        this.mobile_no = mobile_no;
        this.email = email;
    }

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public  String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getMobile_no() {
        return mobile_no;
    }

    public void setMobile_no(int mobile_no) {
        this.mobile_no = mobile_no;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStudentDetail()
    {
        String details =this.s_id+","+this.first_name+","+this.last_name+","+this.city+","+this.mobile_no+","+this.email;
        return details;
    }

}
