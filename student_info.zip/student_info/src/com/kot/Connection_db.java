package com.kot;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Connection_db {


    public Connection get_connection() throws IOException {
        Connection connection = null;
        FileReader reader=new FileReader("..\\student_info\\Resources\\DB.properties");

        Properties properties = new Properties();
        properties.load(reader);

        String url = properties.getProperty("URL");
        String user = properties.getProperty("USER");
        String password = properties.getProperty("PASSWORD");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url,user,password);

        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        return connection;
    }
}