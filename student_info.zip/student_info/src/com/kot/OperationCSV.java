package com.kot;

import java.io.*;


public class OperationCSV {

    public static void insert_data(Student student) throws IOException {
        File file = new File("..\\student_info\\Output\\students_info.csv");
        BufferedWriter bw = new BufferedWriter( new FileWriter(file,true) );
        if (file != null && file.length() <= 0)
        {
            bw.append("s_id,first_name,last_name,city,mobile_no,email");
            bw.append("\n");
        }
        bw.write(student.getS_id()+","+student.getFirst_name()+","+student.getLast_name()+","+student.getCity()+","+student.getMobile_no()+","+student.getEmail());
        bw.flush();
        bw.newLine();
        bw.close();
    }

    public static void modify (int s_id,String newLine, String operation) throws IOException {
        String line;
        File file = new File("..\\student_info\\Output\\students_info.csv");
        File temp_file = new File("..\\student_info\\Output\\temp.csv");

        BufferedReader br = new BufferedReader( new FileReader( file ) );
        BufferedWriter bw = new BufferedWriter( new FileWriter( temp_file ) );

        while( ( line = br.readLine() ) != null ) {
            if( line.startsWith(String.valueOf(s_id)))
            {
                if(operation.equalsIgnoreCase("update"))
                {
                    bw.write(newLine);
                    bw.newLine();
                    continue;
                }
                else if (operation.equalsIgnoreCase("delete"))
                {
                    continue;
                }
            }

            bw.write(line);
            bw.flush();
            bw.newLine();
        }
        br.close();
        bw.close();

        file.delete();
        temp_file.renameTo(file);
    }
}
